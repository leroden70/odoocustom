document.querySelectorAll("pre code").forEach((code) => {
  const wrapper = code.closest(".code-block");
  if (!wrapper || !navigator.clipboard) return;

  const englishPage = document.documentElement.lang === "en";
  const copyLabel = englishPage ? "Copy" : "Copier";
  const copiedLabel = englishPage ? "Copied!" : "Copié !";

  const button = document.createElement("button");
  button.className = "copy-button";
  button.type = "button";
  button.textContent = copyLabel;
  button.setAttribute("aria-label", englishPage ? "Copy this code" : "Copier ce code");
  button.addEventListener("click", async () => {
    await navigator.clipboard.writeText(code.textContent);
    button.textContent = copiedLabel;
    window.setTimeout(() => { button.textContent = copyLabel; }, 1400);
  });
  wrapper.append(button);
});
